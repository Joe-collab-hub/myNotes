/**
 * Time:2022/3/6 15:06 34
 * Name:index.js
 * Path:html5/day1/销帮帮/js
 * ProjectName:前端
 * Author:突然
 *
 *  Il n'ya qu'un héroïsme au monde : c'est de voir le monde tel qu'il est et de l'aimer.
 */
const brand1 = [
	'img/brand-1.jpg',
	'img/brand-2.jpg',
	'img/brand-3.jpg',
	'img/brand-4.jpg',
	'img/brand-5.jpg',
	'img/brand-6.jpg',
	'img/brand-7.jpg',
	'img/brand-8.jpg',
	'img/brand-9.jpg',
	'img/brand-10.jpg',
	'img/brand-11.jpg',
	'img/brand-12.jpg',
	'img/brand-1.jpg',
	'img/brand-2.jpg',
	'img/brand-3.jpg',
	'img/brand-4.jpg',
	'img/brand-5.jpg',
	'img/brand-6.jpg',
	'img/brand-7.jpg',
	'img/brand-8.jpg',
	'img/brand-9.jpg',
	'img/brand-10.jpg',
	'img/brand-11.jpg',
	'img/brand-12.jpg',
	'img/brand-1.jpg',
	'img/brand-2.jpg',
	'img/brand-3.jpg',
	'img/brand-4.jpg',
	'img/brand-5.jpg',
	'img/brand-6.jpg',
];
